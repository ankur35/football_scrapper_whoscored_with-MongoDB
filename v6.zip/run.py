from scrapers import *
from selenium import webdriver
from models import *
from mongoengine import connect

def run_application(config):
	connect(config['database_name'], host=config['mongodb_host'], port=config['mongodb_port'])

	# reset collections
	if config['reset_database']:
		TeamReport.drop_collection()
		MatchReport.drop_collection()
		StandingTable.drop_collection()

	for season_number,season in enumerate(config['seasons']):
		driver = webdriver.Firefox()

		standings_scraper = StandingsScraper(config['main_url'], driver)
		standings = standings_scraper.get_standings(season)

		for standings_table in standings:
			standings_table.save()

			team_url = config['base_url'] + standings_table.team_url
			team_scraper = TeamScraper(team_url, driver)
			team_report = team_scraper.get_team_report(season)
			team_report.save()

		match_links_scraper = MatchLinksScraper(config['main_url'], driver)
		match_links = match_links_scraper.get_match_links(season)

		for match_link in match_links:
			match_url = config['base_url'] + match_link['match_url']
			match_report_scraper = MatchReportScraper(match_url, driver)
			match_report = match_report_scraper.get_match_report(season)
			match_report.save()

		driver.quit()

		if season_number < len(config['seasons'])-1:
			print('giving the website a little rest. 30 seconds')
			sleep(30)
		else:
			print('this is the last season. goodbye')

	print('\n----- Let us try some queries -----\n')

	match_reports_2018_2019 = MatchReport.objects(season='2018/2019')
	print('example query: find all match reports for 2018/2019 season')
	print('total reports found: ', len(match_reports_2018_2019))

	if len(match_reports_2018_2019) > 0:
		print('printing a part of the first report: \n')
		print('  team1: ', match_reports_2018_2019[0].team1_name)
		print('    pass success: ', match_reports_2018_2019[0].stats.pass_success[0], '%')
		print('  team2: ', match_reports_2018_2019[0].team2_name)
		print('    pass success:', match_reports_2018_2019[0].stats.pass_success[1], '%\n')


if __name__ == '__main__':

	config = {
		'base_url': 'https://www.whoscored.com',
		'main_url': 'https://www.whoscored.com/Regions/81/Tournaments/3/Germany-Bundesliga',
		'seasons': ['2018/2019'],
		'mongodb_host': '127.0.0.1',
		'mongodb_port': 27017,
		'database_name': 'football_data',
		'reset_database': True
	}

	run_application(config)

