from mongoengine import (StringField, ListField, EmbeddedDocumentField,
	EmbeddedDocument, Document)

class GoalReport(EmbeddedDocument):

	total_attempts = ListField()
	open_play = ListField(StringField())
	set_price = ListField(StringField())
	counter_attack = ListField(StringField())
	penalty = ListField(StringField())
	own_goal = ListField(StringField())

class AggressionReport(EmbeddedDocument):

	total_card_reasons = ListField(StringField())
	fouls = ListField(StringField())
	unprofessional = ListField(StringField())
	dive = ListField(StringField())
	other = ListField(StringField())

class PassReport(EmbeddedDocument):

	total_passes = ListField(StringField())
	crosses = ListField(StringField())
	through_balls = ListField(StringField())
	long_balls = ListField(StringField())
	short_passes = ListField(StringField())

class MatchStats(EmbeddedDocument):

	shots = ListField(StringField())
	shots_on_target = ListField(StringField())
	pass_success = ListField(StringField())
	aerial_duel_success = ListField(StringField())
	dribbles_won = ListField(StringField())
	tackles = ListField(StringField())
	possession = ListField(StringField())

class MatchReport(Document):

	team1_name = StringField()
	team2_name = StringField()
	season = StringField()
	#match_url = StringField()
	goal_report = EmbeddedDocumentField(GoalReport)
	pass_report = EmbeddedDocumentField(PassReport)
	aggression_report = EmbeddedDocumentField(AggressionReport)
	stats = EmbeddedDocumentField(MatchStats)

class MatchLink(Document):

	match_id = StringField()
	match_url = StringField()

class StandingTable(Document):

	team_name = StringField()
	team_url = StringField()
	season = StringField()
	plays = StringField()
	wins = StringField()
	draws = StringField()
	losses = StringField()
	goal_for = StringField()
	goal_against = StringField()
	goal_difference = StringField()
	points = StringField()


class PlayerSummary(EmbeddedDocument):

	player_name = StringField()
	player_url = StringField()
	height_in_cm = StringField()
	weight_in_kg = StringField()
	apps = StringField()
	mins_played = StringField()
	goals = StringField()
	assists = StringField()
	yellow_cards = StringField()
	red_cards = StringField()
	shots_per_game = StringField()
	success_passes = StringField()
	aerial_won_per_game = StringField()
	man_of_the_match = StringField()
	rating = StringField()

class PlayerDefensive(EmbeddedDocument):

	player_name = StringField()
	player_url = StringField()
	height_in_cm = StringField()
	weight_in_kg = StringField()
	apps = StringField()
	mins_played = StringField()
	tackles_per_game = StringField()
	interceptions_per_game = StringField()
	fouls_per_game = StringField()
	offsides_won_per_game = StringField()
	clearances_per_game = StringField()
	was_dribbled_per_game = StringField()
	outfielder_block_per_game = StringField()
	own_goals = StringField()
	rating = StringField()

class PlayerOffensive(EmbeddedDocument):

	player_name = StringField()
	player_url = StringField()
	height_in_cm = StringField()
	weight_in_kg = StringField()
	apps = StringField()
	mins_played = StringField()
	goals = StringField()
	assists = StringField()
	shots_per_game = StringField()
	key_passes_per_game = StringField()
	dribbles_won_per_game = StringField()
	fouls_given_per_game = StringField()
	offsides_given_per_game = StringField()
	dispossessed_per_game = StringField()
	turnover_per_game = StringField()
	rating = StringField()

class PlayerPassing(EmbeddedDocument):

	player_name = StringField()
	player_url = StringField()
	height_in_cm = StringField()
	weight_in_kg = StringField()
	apps = StringField()
	mins_played = StringField()
	assists = StringField()
	key_passes_per_game = StringField()
	total_passes_per_game = StringField()
	pass_success = StringField()
	accurate_crosses_per_game = StringField()
	accurate_long_passes_per_game = StringField()
	accurate_through_ball_per_game = StringField()
	rating = StringField()

class PlayerDetailed(EmbeddedDocument):

	player_name = StringField()
	player_url = StringField()
	height_in_cm = StringField()
	weight_in_kg = StringField()
	apps = StringField()
	mins_played = StringField()
	total_shots = StringField()
	shot_out_of_box = StringField()
	shot_six_yard_box = StringField()
	shot_penalty_area = StringField()
	rating = StringField()

class TeamProfile(EmbeddedDocument):

	season = StringField()
	goals_per_game = StringField()
	average_possession = StringField()
	pass_accuracy = StringField()
	shots_per_game = StringField()
	tackles_per_game = StringField()
	dribbles_won_per_game = StringField()
	yellow_cards = StringField()
	red_cards = StringField()

class TeamReport(Document):

	team_name = StringField()
	#team_url = StringField()
	season = StringField()
	summary_report = ListField(EmbeddedDocumentField(PlayerSummary))
	defensive_report = ListField(EmbeddedDocumentField(PlayerDefensive))
	offensive_report = ListField(EmbeddedDocumentField(PlayerOffensive))
	passing_report = ListField(EmbeddedDocumentField(PlayerPassing))
	detailed_report = ListField(EmbeddedDocumentField(PlayerDetailed))
	profile = EmbeddedDocumentField(TeamProfile)
