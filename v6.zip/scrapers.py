from bs4 import BeautifulSoup
from time import sleep, time
from selenium.webdriver.support.ui import Select
from models import *


def timeit(data_name):
	def inner(f):
		def wrapper(*args, **kwargs):
			start = time()
			print('scraping..')
			result = f(*args, **kwargs)
			end = time()
			if len(args) > 1:
				print('Scraped {0} in {1: .2f} seconds for season {2}. saving..'.format(
					data_name,
					end-start,
					args[1]))
			else:
				print('Scraped {0} in {1: .2f} seconds. saving..'.format(
					data_name,
					end-start))

			return result
		return wrapper
	return inner

class Scraper(object):

	def __init__(self, url, driver):
		self.url = url
		self.driver = driver

	def accept_cookies_banner(self):
		try:
			banner_button = self.driver.find_element_by_class_name('banner_save--3Xnwp')
			banner_button.click()
			sleep(2)
		except:
			pass

	def remove_ad(self):
		try:
			buttons = self.driver.find_elements_by_tag_name('input')

			for button in buttons:
				if button.get_attribute('alt') == 'Close':
					button.click()
					sleep(2)
		except:
			pass


class MatchLinksScraper(Scraper):

	@timeit('MatchLinks')
	def get_match_links(self, season):
		self.driver.get(self.url)
		self.accept_cookies_banner()
		self.remove_ad()
		self.select_season(season)
		self.select_fixtures_page()

		pages = []

		prev_link = self.find_prev_link()
		while prev_link.get_attribute('title') == 'View previous month':
			pages.append(self.driver.page_source)
			self.remove_ad()
			prev_link.click()
			sleep(2)
			prev_link = self.find_prev_link()

		data = self.extract_match_links(pages)
		return data

	def extract_match_links(self, pages):
		data = []

		for page in pages:
			soup = BeautifulSoup(page, 'html.parser')
			links = soup.find(id='tournament-fixture').find_all(**{'class': 'match-link'})

			for link in links:
				if not link.text == 'Match Report':
					continue
				match_link = {
					'match_id': link['href'].split('/')[4],
					'match_url': link['href']
				}
				data.append(match_link)

		return data

	def find_prev_link(self):
		date_controller = self.driver.find_element_by_id('date-controller')
		links = date_controller.find_elements_by_tag_name('a')
		return links[0]

	def select_season(self, season):
		season_dropdown = Select(self.driver.find_element_by_id('seasons'))
		season_dropdown.select_by_visible_text(season)
		sleep(3)

	def select_fixtures_page(self):
		fixtures_link = self.driver.find_element_by_link_text('Fixtures')
		fixtures_link.click()
		sleep(3)


class MatchReportScraper(Scraper):

	@timeit('MatchReport')
	def get_match_report(self, season):
		self.driver.get(self.url)
		sleep(4)

		pages = [self.driver.page_source]
		tab_names = ['Pass Types', 'Card Situations']

		for tab_name in tab_names:
			self.accept_cookies_banner()
			self.remove_ad()
			self.select_live_chart_tab(tab_name)
			pages.append(self.driver.page_source)

		return self.extract_match_report(pages, season)

	def extract_match_report(self, pages, season):
		team_names = self.extract_team_names(pages[0])

		return MatchReport(
			team1_name=team_names[0],
			team2_name=team_names[1],
			season=season,
			goal_report=self.extract_goal_report(pages[0]),
			pass_report=self.extract_pass_report(pages[1]),
			aggression_report=self.extract_aggression_report(pages[2]),
			stats=self.extract_match_stats(pages[0]))

	def extract_team_names(self, page):
		soup = BeautifulSoup(page, 'html.parser')
		match_header = soup.find(id='match-header')
		team_links = match_header.find_all(**{'class': 'team-link'})
		return [team_link.text for team_link in team_links]

	def extract_goal_report(self, page):
		data = {}

		soup = BeautifulSoup(page, 'html.parser')
		section = soup.find(id='live-goals')
		stats = section.find_all(**{'class': 'stat'})

		names = [
			'total_attempts',
			'open_play',
			'set_price',
			'counter_attack',
			'penalty',
			'own_goal'
		]

		for i, stat in enumerate(stats):
			if i == len(names):
				break
			data_items = stat.find_all(**{'class': 'pulsable'})
			data[names[i]] = [data_items[0].text, data_items[1].text]

		return GoalReport(**data)

	def extract_pass_report(self, page):
		data = {}

		soup = BeautifulSoup(page, 'html.parser')
		section = soup.find(id='live-passes')
		stats = section.find_all(**{'class': 'stat'})

		names = [
			'total_passes',
			'crosses',
			'through_balls',
			'long_balls',
			'short_passes',
		]

		for i, stat in enumerate(stats):
			if i == len(names):
				break
			data_items = stat.find_all(**{'class': 'pulsable'})
			data[names[i]] = [data_items[0].text, data_items[1].text]

		return PassReport(**data)

	def extract_aggression_report(self, page):
		data = {}

		soup = BeautifulSoup(page, 'html.parser')
		section = soup.find(id='live-aggression')
		stats = section.find_all(**{'class': 'stat'})

		names = [
			'total_card_reasons',
			'fouls',
			'unprofessional',
			'dive',
			'other'
		]

		for i, stat in enumerate(stats):
			if i == len(names):
				break
			data_items = stat.find_all(**{'class': 'pulsable'})
			data[names[i]] = [data_items[0].text, data_items[1].text]

		return AggressionReport(**data)

	def extract_match_stats(self, page):
		data = {}

		soup = BeautifulSoup(page, 'html.parser')
		section = soup.find(id='match-report-team-statistics')
		stats = section.find_all(**{'class': 'stat'})

		names = [
			'shots',
			'shots_on_target',
			'pass_success',
			'aerial_duel_success',
			'dribbles_won',
			'tackles',
			'possession'
		]

		for i, stat in enumerate(stats):
			if i == len(names):
				break
			data_items = stat.find_all(**{'class': 'pulsable'})
			data[names[i]] = [data_items[0].text, data_items[1].text]

		return MatchStats(**data)

	def select_live_chart_tab(self, name):
		section = self.driver.find_element_by_id('live-chart-stats')
		link = section.find_element_by_link_text(name)
		link.click()
		sleep(4)


class TeamScraper(Scraper):

	@timeit('TeamReport')
	def get_team_report(self, season):
		self.driver.get(self.url)
		sleep(2)
		self.accept_cookies_banner()
		self.remove_ad()
		self.select_season(season)

		tab_names = ['Defensive', 'Offensive', 'Passing', 'Detailed']

		for tab_name in tab_names:
			self.select_squad_tab(tab_name)

		page = self.driver.page_source
		return self.extract_team_report(season, page)

	def select_squad_tab(self, name):
		try:
			section = self.driver.find_element_by_id('team-squad-stats')
		except:
			section = self.driver.find_element_by_id('team-squad-archive-stats')
		link = section.find_element_by_link_text(name)
		self.remove_ad()
		link.click()
		sleep(3)

	def select_history_page(self):
		navigation = self.driver.find_element_by_id('sub-navigation')
		link = navigation.find_element_by_link_text('History')
		link.click()
		sleep(3)

	def select_season(self, season):
		if not season == '2018/2019':
			self.remove_ad()
			self.select_history_page()
			season_dropdown = Select(self.driver.find_element_by_id('stageId'))
			season_text = 'Bundesliga - {}'.format(season)
			self.remove_ad()
			season_dropdown.select_by_visible_text(season_text)
			sleep(3)

	def extract_team_report(self, season, page):
		soup = BeautifulSoup(page, 'html.parser')

		selected_page = soup.find(id='sub-navigation').find('a', {'class': 'selected'}).text
		name_addition = 'archive-' if selected_page == 'History' else ''

		summary_section = soup.find(id='team-squad-{}stats-summary'.format(name_addition))
		defensive_section = soup.find(id='team-squad-{}stats-defensive'.format(name_addition))
		offensive_section = soup.find(id='team-squad-{}stats-offensive'.format(name_addition))
		passing_section = soup.find(id='team-squad-{}stats-passing'.format(name_addition))
		detailed_section = soup.find(id='team-squad-{}stats-detailed'.format(name_addition))
		profile_section = soup.find(**{'class': 'team-profile-side-box'})

		return TeamReport(
			team_name=soup.find(**{'class': 'team-header-name'}).text,
			season=season,
			summary_report=self.extract_summary_report(summary_section),
			defensive_report=self.extract_defensive_report(defensive_section),
			offensive_report=self.extract_offensive_report(offensive_section),
			passing_report=self.extract_passing_report(passing_section),
			detailed_report=self.extract_detailed_report(detailed_section),
			profile=self.extract_team_profile(profile_section))

	def extract_summary_report(self, section):
		data = []

		table = section.find(id='player-table-statistics-body')
		rows = table.find_all('tr')

		for row in rows:
			cols = row.find_all('td')

			player_link = row.find(**{'class': 'player-link'})
			if player_link is None:
				print('skipping..', cols)

			data.append(PlayerSummary(**{
				'player_name': row.find(**{'class': 'player-link'})['href'],
				'player_url': row.find(**{'class': 'player-link'}).text,
				'height_in_cm': cols[3].text,
				'weight_in_kg': cols[4].text,
				'apps': cols[5].text,
				'mins_played': cols[6].text,
				'goals': cols[7].text,
				'assists': cols[8].text,
				'yellow_cards': cols[9].text,
				'red_cards': cols[10].text,
				'shots_per_game': cols[11].text,
				'success_passes': cols[12].text,
				'aerial_won_per_game': cols[13].text,
				'man_of_the_match': cols[14].text,
				'rating': cols[15].text
			}))

		return data

	def extract_defensive_report(self, section):
		data = []

		table = section.find(id='player-table-statistics-body')
		rows = table.find_all('tr')

		for row in rows:
			cols = row.find_all('td')

			player_link = row.find(**{'class': 'player-link'})
			if player_link is None:
				print('skipping..', cols)

			data.append(PlayerDefensive(**{
				'player_url': row.find(**{'class': 'player-link'})['href'],
				'player_name': row.find(**{'class': 'player-link'}).text,
				'height_in_cm': cols[3].text,
				'weight_in_kg': cols[4].text,
				'apps': cols[5].text,
				'mins_played': cols[6].text,
				'tackles_per_game': cols[7].text,
				'interceptions_per_game': cols[8].text,
				'fouls_per_game': cols[9].text,
				'offsides_won_per_game': cols[10].text,
				'clearances_per_game': cols[11].text,
				'was_dribbled_per_game': cols[12].text,
				'outfielder_block_per_game': cols[13].text,
				'own_goals': cols[14].text,
				'rating': cols[15].text
			}))

		return data

	def extract_offensive_report(self, section):
		data = []

		table = section.find(id='player-table-statistics-body')
		rows = table.find_all('tr')

		for row in rows:
			cols = row.find_all('td')

			player_link = row.find(**{'class': 'player-link'})
			if player_link is None:
				print('skipping..', cols)

			data.append(PlayerOffensive(**{
				'player_url': row.find(**{'class': 'player-link'})['href'],
				'player_name': row.find(**{'class': 'player-link'}).text,
				'height_in_cm': cols[3].text,
				'weight_in_kg': cols[4].text,
				'apps': cols[5].text,
				'mins_played': cols[6].text,
				'goals': cols[7].text,
				'assists': cols[8].text,
				'shots_per_game': cols[9].text,
				'key_passes_per_game': cols[10].text,
				'dribbles_won_per_game': cols[11].text,
				'fouls_given_per_game': cols[12].text,
				'offsides_given_per_game': cols[13].text,
				'dispossessed_per_game': cols[14].text,
				'turnover_per_game': cols[15].text,
				'rating': cols[16].text
			}))

		return data

	def extract_passing_report(self, section):
		data = []

		table = section.find(id='player-table-statistics-body')
		rows = table.find_all('tr')

		for row in rows:
			cols = row.find_all('td')

			player_link = row.find(**{'class': 'player-link'})
			if player_link is None:
				print('skipping..', cols)
			data.append(PlayerPassing(**{
				'player_url': row.find(**{'class': 'player-link'})['href'],
				'player_name': row.find(**{'class': 'player-link'}).text,
				'height_in_cm': cols[3].text,
				'weight_in_kg': cols[4].text,
				'apps': cols[5].text,
				'mins_played': cols[6].text,
				'assists': cols[7].text,
				'key_passes_per_game': cols[8].text,
				'total_passes_per_game': cols[9].text,
				'pass_success': cols[10].text,
				'accurate_crosses_per_game': cols[11].text,
				'accurate_long_passes_per_game': cols[12].text,
				'accurate_through_ball_per_game': cols[13].text,
				'rating': cols[14].text
			}))

		return data

	def extract_detailed_report(self, section):
		data = []

		table = section.find(id='player-table-statistics-body')
		rows = table.find_all('tr')

		for row in rows:
			cols = row.find_all('td')

			player_link = row.find(**{'class': 'player-link'})
			if player_link is None:
				print('skipping..', scols)

			data.append(PlayerDetailed(**{
				'player_url': row.find(**{'class': 'player-link'})['href'],
				'player_name': row.find(**{'class': 'player-link'}).text,
				'height_in_cm': cols[3].text,
				'weight_in_kg': cols[4].text,
				'apps': cols[5].text,
				'mins_played': cols[6].text,
				'total_shots': cols[7].text,
				'shot_out_of_box': cols[8].text,
				'shot_six_yard_box': cols[9].text,
				'shot_penalty_area': cols[10].text,
				'rating': cols[11].text
			}))

		return data

	def extract_team_profile(self, section):
		stats_container = section.find(**{'class': 'stats-container'})
		dynamic_list = stats_container.find(**{'class': 'stats'})
		items = dynamic_list.find_all('dd')

		return TeamProfile(**{
			'season': items[1].text,
			'goals_per_game': items[2].text,
			'average_possession': items[3].text,
			'pass_accuracy': items[4].text,
			'shots_per_game': items[5].text,
			'tackles_per_game': items[6].text,
			'dribbles_won_per_game': items[7].text,
			'yellow_cards': items[8].find(**{'class': 'yellow-card-box'}).text,
			'red_cards': items[8].find(**{'class': 'red-card-box'}).text
		})


class StandingsScraper(Scraper):

	@timeit('StandingTables')
	def get_standings(self, season):
		self.driver.get(self.url)
		sleep(2)
		self.accept_cookies_banner()
		self.remove_ad()
		self.select_season(season)

		return self.extract_standings(self.driver.page_source, season)

	def extract_standings(self, page, season):
		data = []

		soup = BeautifulSoup(page, 'html.parser')
		table = soup.find_all('tbody', **{'class': 'standings'})
		rows = table[0].find_all('tr')
		for row in rows:
			items = row.find_all('td')

			team_name = items[1].find('a').text
			team_link = items[1].find('a')['href']

			data.append(StandingTable(**{
				'season': season,
				'team_name': team_name,
				'team_url': team_link,
				'plays': items[2].text,
				'wins': items[3].text,
				'draws': items[4].text,
				'losses': items[5].text,
				'goal_for': items[6].text,
				'goal_against': items[7].text,
				'goal_difference': items[8].text,
				'points': items[9].text
			}))

		return data

	def select_season(self, season):
		season_dropdown = Select(self.driver.find_element_by_id('seasons'))
		season_dropdown.select_by_visible_text(season)
		sleep(3)